var calc = parseInt(prompt("votre chiffre"));

for (var i = 0; i < 13; i++) {
    alert(+calc+ " x " +i+ " = " +calc * i +".")
}