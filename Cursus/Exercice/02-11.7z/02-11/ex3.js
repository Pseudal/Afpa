function main(){
    var a = parseInt(prompt("rentrez un nombre pour avoir un joli pas carré\n"));
    var b = 0;
    var c = 0;
    var i = 0;

    c = a * a;
    while(i != a){
        i++;      
        if (b == c)
        {
            alert("Voila ton pas carré, Press ENTER key to quit\n");  
            return;
        } else if (i == a) {
            i = 0;
            b++;
            console.log("*\n");
        } else {
            b++;
            console.log("*" );
        }
    }
}
main();