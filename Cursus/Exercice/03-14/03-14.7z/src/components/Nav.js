import React from 'react';

const Nav = () => {
    return (
        <div>
            <ul id='nav'>
                <li>Home</li>
                <li>lorem</li>
                <li>lorem2</li>
            </ul>
        </div>
    );
};

export default Nav;