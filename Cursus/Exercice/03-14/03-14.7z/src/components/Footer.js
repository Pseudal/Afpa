import React from 'react';

const Footer = () => {
    return (
        <div>
            <ul id='footer'>
                <li>Adrien©</li>
                <li>Mention legale</li>
                <li>Newletter</li>
                <li>à propos</li>
            </ul>
        </div>
    );
};

export default Footer;