import React from "react";

const Body = () => {
  return (
    <div id="top">
        <div>
            <h1>Exercice React</h1>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta eaque
                quis id earum dolores laborum sunt, nobis, magni dignissimos enim
                laudantium quidem temporibus, quasi et.
            </p>
            <img width={256} src="./logo512.png" alt="" />
        </div>
    </div>
  );
};

export default Body;
