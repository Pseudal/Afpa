import React from 'react';

const Comp1 = () => {
    return (
        <div>
            <h1>composant1</h1>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, commodi quia, qui non libero eos tempore autem deleniti dolorum ab voluptatem itaque esse porro architecto ea magnam aspernatur dolores pariatur.
        </div>
    );
};

export default Comp1;