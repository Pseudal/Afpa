import React from 'react';

const Comp2 = () => {
    return (
        <div>
        <h1>composant2</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa aut earum repudiandae illo iure, quis quisquam quas quidem in commodi sequi molestias quasi similique est fugit eum dolores explicabo. Ex.</p>
        </div>
    );
};

export default Comp2;